# Sales Reporting Pipeline

Produce repeatable, reconciled net-sales reports from orders, product categories, payments and returns.

Revision: 2.0.0; deterministic seed: 2103.

Seed 2103 determines amounts for 1,200 orders over 90 days and 24 products. Every 9th order is cancelled; every 41st date is invalid, 43rd product unknown, 47th amount negative (precedence in that order). Eligible every 13th order has a half refund. One payment references an unknown order.

Run `python main.py`, then `python test_project.py`.
Dependencies: matplotlib.
Input files are read-only in Runtime. Edit the Python source files.
