# Marketplace Analytics

Analyze customer cohorts, repeat purchasing and revenue coverage with pandas, preserving unmatched orders and delivering data-backed charts.

Revision: 2.0.0; deterministic seed: 2105.

Seed 2105 chooses customers and amounts for 2,400 base orders across six months, 240 customers and 32 products. The first 180 customers can repeat; the final 60 base orders introduce one-time customers, subject to the same quality exclusions. Every 37th amount is missing, otherwise every 41st negative; every 53rd customer and 67th product is unmatched; every 59th order is duplicated. Order month cannot precede the known customer cohort.

Run `python main.py`, then `python test_project.py`.
Dependencies: pandas, matplotlib.
Input files are read-only in Runtime. Edit the Python source files.
