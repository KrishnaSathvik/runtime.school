# Customer Data Quality System

Build a reusable customer-feed cleaning tool that accounts for every source record and explains every rejection.

Revision: 2.0.0; deterministic seed: 2101.

Seed 2101 selects regions for 600 customers. Divisibility rules inject missing names (19), invalid email (17), blocked domains (13), duplicate emails (11), and conflicting IDs (23), in that precedence order. File A precedes B. Source index is the concatenated zero-based position.

Run `python main.py`, then `python test_project.py`.
Dependencies: Python standard library.
Input files are read-only in Runtime. Edit the Python source files.
