# Retail Checkout & Order Processing

Deliver a catalog-driven checkout engine with validated carts, discounts, tax, cancellation/refund accounting and receipts.

Revision: 2.0.0; deterministic seed: 2102.

Seed 2102 creates 64 products and 48 carts with one to four lines. Cases divisible by 11 have negative quantity, 13 unknown SKU, 17 boolean quantity (in that order); statuses include refunds every 7th case and cancellations every 9th remaining case. Amounts are integer cents.

Run `python main.py`, then `python test_project.py`.
Dependencies: Python standard library.
Input files are read-only in Runtime. Edit the Python source files.
