# Product Analytics Investigation

Investigate product activity with validated events, inactivity-based sessions, chronological conversion, weekly retention and a chart.

Revision: 2.0.0; deterministic seed: 2104.

Seed 2104 shuffles events for 140 users over eight weeks. User modulo 3 determines first week, modulo 5 creates gaps, modulo 3 creates abandoned sessions, modulo 17 creates buy-before-view sessions. Every 71st source event is duplicated; missing fields are injected every 113th and malformed JSON every 227th. Sessions use a 30-minute inactivity threshold.

Run `python main.py`, then `python test_project.py`.
Dependencies: matplotlib.
Input files are read-only in Runtime. Edit the Python source files.
