import unittest
import _acceptance

if __name__ == "__main__":
    suite = unittest.TestSuite(unittest.FunctionTestCase(getattr(_acceptance, name)) for name in ['parsing', 'validation', 'merging', 'replay', 'delivery'])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
