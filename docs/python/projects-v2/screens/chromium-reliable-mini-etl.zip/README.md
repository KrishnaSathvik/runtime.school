# Incremental ETL Pipeline

Build a replay-safe incremental pipeline with configurable schema validation, deterministic upserts, rejection evidence and a run manifest.

Revision: 2.0.0; deterministic seed: 2106.

Seed 2106 generates 1,500 source lines across three ordered batches of 500, updating 420 IDs at versions 1–5. Every 29th amount is negative, otherwise every 31st version is boolean and 37th ID missing. Every 43rd line overrides these with malformed JSON. The initial target contains 200 version-1 records.

Run `python main.py`, then `python test_project.py`.
Dependencies: Python standard library.
Input files are read-only in Runtime. Edit the Python source files.
